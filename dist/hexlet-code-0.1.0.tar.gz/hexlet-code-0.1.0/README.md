### Hexlet tests and linter status:
[![Actions Status](https://github.com/avoavvpotato/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/avoavvpotato/python-project-lvl1/actions)
<a href="https://codeclimate.com/github/avoavvpotato/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/d7a1872f188868fc8c10/maintainability" /></a>
<p>Game Even: </p>
<a href="https://asciinema.org/a/nr5nlC8IpGJyiN3P9ZbFHnF4i" target="_blank"><img src="https://asciinema.org/a/nr5nlC8IpGJyiN3P9ZbFHnF4i.svg" /></a>
<p>Game Calculator: </p>
<a href="https://asciinema.org/a/pzI8EAUEnw2EHDCJmiAX7yMpJ" target="_blank"><img src="https://asciinema.org/a/pzI8EAUEnw2EHDCJmiAX7yMpJ.svg" /></a>
<p>Game GCD: </p>
<a href="https://asciinema.org/a/ZLaMYf3YYzKyGIPSGExf8PTJe" target="_blank"><img src="https://asciinema.org/a/ZLaMYf3YYzKyGIPSGExf8PTJe.svg" /></a>
<p>Game Progression: </p>
<a href="https://asciinema.org/a/S34xtrnCu9wCNTE7nFBSKUXRZ" target="_blank"><img src="https://asciinema.org/a/S34xtrnCu9wCNTE7nFBSKUXRZ.svg" /></a>