### Hexlet tests and linter status:
[![Actions Status](https://github.com/avoavvpotato/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/avoavvpotato/python-project-lvl1/actions)
<a href="https://codeclimate.com/github/avoavvpotato/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/d7a1872f188868fc8c10/maintainability" /></a>