# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/avoavvpotato/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/avoavvpotato/python-project-lvl1/actions)\n<a href="https://codeclimate.com/github/avoavvpotato/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/d7a1872f188868fc8c10/maintainability" /></a>\n<p>Game Even: </p>\n<a href="https://asciinema.org/a/nr5nlC8IpGJyiN3P9ZbFHnF4i" target="_blank"><img src="https://asciinema.org/a/nr5nlC8IpGJyiN3P9ZbFHnF4i.svg" /></a>\n<p>Game Calculator: </p>\n<a href="https://asciinema.org/a/pzI8EAUEnw2EHDCJmiAX7yMpJ" target="_blank"><img src="https://asciinema.org/a/pzI8EAUEnw2EHDCJmiAX7yMpJ.svg" /></a>\n<p>Game GCD: </p>\n<a href="https://asciinema.org/a/ZLaMYf3YYzKyGIPSGExf8PTJe" target="_blank"><img src="https://asciinema.org/a/ZLaMYf3YYzKyGIPSGExf8PTJe.svg" /></a>\n<p>Game Progression: </p>\n<a href="https://asciinema.org/a/S34xtrnCu9wCNTE7nFBSKUXRZ" target="_blank"><img src="https://asciinema.org/a/S34xtrnCu9wCNTE7nFBSKUXRZ.svg" /></a>\n<p>Game Prime: </p>\n<a href="https://asciinema.org/a/BMQdU32MiwHidEIwthwRyRFRy" target="_blank"><img src="https://asciinema.org/a/BMQdU32MiwHidEIwthwRyRFRy.svg" /></a>',
    'author': 'Darya Tarakanovskaya',
    'author_email': 'd.tarakanovskaya@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
